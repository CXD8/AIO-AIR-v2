#pragma once
#include <Arduino.h>
#include <esp_arduino_version.h>

namespace Backlight {
// Hardware PWM: does not consume loop time or alter sensor sampling.
inline bool begin(int pin,uint8_t brightness,bool activeHigh) {
  if(pin<0) return true;
  constexpr uint32_t frequency=25000;
  constexpr uint8_t resolution=8;
  uint32_t duty=activeHigh?brightness:255-brightness;
  // Preload OFF before attaching PWM. Panel's pull-up can light it during boot.
  digitalWrite(pin,activeHigh?LOW:HIGH);
  pinMode(pin,OUTPUT);
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  if(!ledcAttach(pin,frequency,resolution)) return false;
  if(!ledcWrite(pin,duty)) {
    ledcDetach(pin);
    digitalWrite(pin,activeHigh?LOW:HIGH);
    return false;
  }
#else
  constexpr uint8_t channel=0; // Reserved for BL on Arduino-ESP32 2.x.
  if(ledcSetup(channel,frequency,resolution)==0) return false;
  ledcAttachPin(pin,channel);
  ledcWrite(channel,duty);
#endif
  return true;
}
}
