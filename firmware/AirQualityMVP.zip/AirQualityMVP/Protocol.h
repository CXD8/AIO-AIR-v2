#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>

namespace Protocol {
inline uint8_t crc8(const uint8_t* p, size_t n) {
  uint8_t c = 0xff;
  while (n--) {
    c ^= *p++;
    for (int i=0; i<8; ++i) c = (c & 0x80) ? (c<<1)^0x31 : c<<1;
  }
  return c;
}
inline bool escaped(uint8_t b) { return b==0x7e || b==0x7d || b==0x11 || b==0x13; }
inline float beFloat(const uint8_t* p) {
  static_assert(sizeof(float)==4, "32-bit float required");
  uint32_t bits = uint32_t(p[0])<<24 | uint32_t(p[1])<<16 | uint32_t(p[2])<<8 | p[3];
  float f; memcpy(&f, &bits, 4); return f;
}
// Bounded SHDLC receiver. feed() returns true only for a complete valid frame.
struct Frame {
  uint8_t bytes[260]{};
  size_t count=0;
  bool active=false, escape=false;
  void reset() { count=0; active=false; escape=false; }
  bool feed(uint8_t b) {
    if (b==0x7e) {
      bool valid=active && !escape && count>=5 && count==size_t(bytes[3])+5;
      uint8_t sum=0;
      if (valid) { for (size_t i=0;i<count;++i) sum+=bytes[i]; valid=sum==0xff; }
      active=true; escape=false; count=0;
      return valid;
    }
    if (!active) return false;
    if (escape) { b^=0x20; escape=false; }
    else if (b==0x7d) { escape=true; return false; }
    if (count>=sizeof(bytes)) { reset(); return false; }
    bytes[count++]=b;
    return false;
  }
};
}
