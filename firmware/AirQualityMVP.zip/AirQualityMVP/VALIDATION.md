# PWM and status-dot update

Compiled and ran the Backlight.h helper against temporary Arduino API stubs for both core-version branches. Checked unmanaged mode makes no pin calls, 0/128/255 duty, active-low inversion, and attach failure. This checks application logic, not actual ESP32 library linkage or PWM hardware. Reviewed dot coordinates, LIVE-label replacement and retention of warning/learning labels. No full ESP32 target compile or physical display/PWM test performed.

LEDC API reference: https://docs.espressif.com/projects/arduino-esp32/en/latest/api/ledc.html

# Dashboard consistency update

Reviewed 240x320 coordinates: 8px outside margins, 4px row gaps, 224px full cards / 108px half cards, matching 12px content insets. Large readings use GFX text bounds to select a fitting font. Reviewed labels including LEARNING, OFFLINE, WARNING and 500+ AQI; footer uptime is bounded using days after 24 hours. No target compile or physical display test was performed for this UI-only update.

# Wi-Fi / Home Assistant update

Native C++ network freshness tests passed for expiry boundaries, invalid/nonfinite data, real zero values, and millis wraparound. Existing protocol, alert and AQI tests also passed. Reviewed discovery fields against Home Assistant MQTT sensor documentation and ArduinoJson 7 API. Network clients are used only by the worker task; sensor snapshots use a FreeRTOS copying queue.

Not performed: ESP32-S3 target compilation, physical Wi-Fi timing tests, or a live MQTT/Home Assistant integration test. Follow the acceptance checks in WIFI_HOME_ASSISTANT.md after upload.

# LCD document check

Visually inspected SPI adapter schematic sheet 1; verified vendor ESP32 application overrides inversion to false, and driver maps false to INVOFF. Read panel transflective specification. Updated default inversion; no physical colour test or target compile performed.

# AQI and colour checks

Native C++ tests passed for all PM2.5 band endpoints, decimal truncation, an EPA worked interpolation example, negative/NaN/infinite input, the 500+ display cap, monotonicity and green/orange/red boundaries. Source verified against the May 2026 EPA document. Alert latch tests retained. No target compile or on-device test of this update was performed.

Run the new tests with:

```sh
g++ -std=c++11 -Wall -Wextra -Werror tests/aqi_test.cpp -o /tmp/aqi-test
/tmp/aqi-test
```

# Current validation

- Native C++ alert tests pass: trigger boundaries, hold duration, hysteresis, interrupted hold, invalid/stale/NaN suppression and uint32 millisecond wraparound.
- Previous SHDLC/CRC protocol tests retained; protocol implementation unchanged in this update.
- Corrected constructor compatibility after the user reported a compile error: both algorithms now use default constructors (one-second sampling). The previous claim that the NOx float constructor had been verified was incorrect. Full target compilation remains unverified.
- Reviewed SGP41 conditioning, algorithm blackout display, input validation, fixed nominal one-second schedule, and reset-on-sampling-gap behavior.
- Confirmed working GPIOs and optional backlight configuration remain unchanged.
- Checked HIGH labels fit the existing portrait card areas; flashing changes only the affected card background/outline, keeping readings visible.

Not performed: full ESP32-S3 target compilation or physical sensor/display testing of this version. This environment previously could not install the target board package. Host tests do not establish Arduino library linkage, device timing or electrical reliability.

Run host tests:

```sh
g++ -std=c++11 -Wall -Wextra -Werror tests/alerts_test.cpp -o /tmp/alerts-test
/tmp/alerts-test
g++ -std=c++11 -Wall -Wextra -Werror tests/protocol_test.cpp -o /tmp/protocol-test
/tmp/protocol-test
```
