# Backlight brightness and live indicators

Connect display **BL → GPIO5** (onboard backlight transistor control). In `AirQualityMVP.ino`:

```cpp
constexpr int BACKLIGHT_PIN = 5; // -1 for unmanaged/disconnected BL
constexpr bool BACKLIGHT_ON = true;
constexpr uint8_t BACKLIGHT_BRIGHTNESS = 128; // 0 off, 255 full brightness
```

BACKLIGHT_ON=false overrides the brightness to zero. The LCD still updates with its light off. Brightness is linear PWM duty, not perceptually linear brightness. Hardware PWM runs at 5kHz/8-bit; the helper handles Arduino-ESP32 2.x and 3.x LEDC APIs. The existing adapter pull-up can turn the light on briefly during boot. If BL is disconnected, this setting cannot change the backlight. This version adds local brightness configuration, not an MQTT light entity.

Fresh sensor data is represented by a green dot breathing over two seconds. Card colour continues to show measurement severity. HIGH, WARNING, STALE, WAITING, WARMING, LEARNING and OFFLINE remain explicit text. Climate tiles have matching freshness dots; the footer shows a count and a pulsing dot when all three sensor groups are fresh. A hollow dot means freshness is missing. Animation uses the existing redraw schedule and adds no delays.

Keep your existing NetworkConfig.h when upgrading to preserve Wi-Fi/MQTT credentials.

# Consistent dashboard layout

Cards now share 8px corners, 12px content padding, matching labels and status badges. CO2 and PM2.5 use matching large values and right-aligned units; temperature/humidity form a matched pair. VOC/NOx share aligned value columns. The footer separates uptime, network status and sensor availability. Existing colours, alert flashes, readings, wiring and MQTT settings are preserved.

# Wi-Fi / Home Assistant update

See [WIFI_HOME_ASSISTANT.md](WIFI_HOME_ASSISTANT.md) for setup. Install PubSubClient 2.8+ and ArduinoJson 7.x, then fill in NetworkConfig.h. Empty settings keep local operation enabled. Working sensor/display GPIOs are unchanged.

# LCD configuration correction

Manufacturer documents confirm inversion OFF and active-high MOSFET backlight control. See `LCD_NOTES.md` for wiring and exact source details; it supersedes earlier backlight uncertainty below. The sketch default is now `INVERT_DISPLAY = false`.

# AQI and three-colour dashboard update

The top panel now shows **US AQI EST / PM2.5 — LIVE SAMPLE**. This uses the current SPS30 PM2.5 reading with EPA's May 2026 concentration breakpoints, truncation to one decimal place, interpolation and integer rounding. It is a PM2.5-only live estimate, not a 24-hour AQI, AirNow NowCast, Australian AQI, or a combined score for all measured gases. CO2 and SGP41 indices do not enter this calculation. Values beyond the implemented display range show **500+**. Missing/stale PM or a sensor warning displays **--**.

The requested three-colour palette is deliberately simplified; it is not EPA's six-colour scale. Official source: https://document.airnow.gov/technical-assistance-document-for-the-reporting-of-daily-air-quailty.pdf

| Area | Green | Orange | Red |
|---|---|---|---|
| PM2.5 and AQI | Estimate 0–50 | 51–100 | >100 |
| CO2 | <1000 ppm | 1000–1499 ppm | >=1500 ppm |
| Gas indices | VOC <120 AND NOx <10 | VOC >=120 OR NOx >=10 | VOC >=150 OR NOx >=20 |
| Temperature | 18–26 C | 15–<18 or >26–30 C | <15 or >30 C |
| Humidity | 40–60% | 30–<40 or >60–70% | <30 or >70% |

For gas indices the worse band wins. Gas colours stay neutral during the five-minute learning grace period. Temperature/humidity ranges are adjustable application comfort preferences, not health limits. Invalid/stale readings stay neutral grey. Colours reflect the current sample immediately; the existing 30-second alert latches still control pulsing. A latched alert keeps its card red until its lower reset threshold is reached. The existing PM alert begins at 35 ug/m3, slightly before the AQI red-band boundary of 35.5 ug/m3; a sustained alert can therefore turn that card red first.

Colour thresholds and AQI conversion are in **AirQuality.h**; flashing thresholds are in **Alerts.h**. No new dependencies beyond the previous version. Keep the corrected default VOC/NOx constructors and your existing working wiring/backlight settings. The previous sensor protocol functions are unchanged; SPS30 serial logs now include the estimate.

---

# AirQualityMVP — dashboard, advisory alerts and gas indices

Open `AirQualityMVP.ino` from this extracted folder. Keep all `.h` files alongside it. Select ESP32S3 Dev Module in Arduino IDE and use your existing working board/USB settings. Serial Monitor: 115200 baud.

## Libraries

Install via Arduino Library Manager:
- Adafruit ST7735 and ST7789 Library
- Adafruit SCD30
- **Sensirion Gas Index Algorithm** (new for this version)

Accept Adafruit GFX/BusIO/Unified Sensor dependencies. If the Sensirion library isn't listed, download its ZIP from https://github.com/Sensirion/arduino-gas-index-algorithm and use Sketch > Include Library > Add .ZIP Library. This sketch only uses the algorithm, so its example-only SHT4x/SGP41 driver dependencies aren't required by our source. SGP41 communication and SPS30 UART protocol remain included here.

## Wiring retained

| Function | ESP32 GPIO |
|---|---|
| SCD30 and SGP41 SDA | 8 |
| SCD30 and SGP41 SCL | 3 |
| SPS30 RX (ESP32 receives from sensor TX pin 3) | 18 |
| SPS30 TX (ESP32 transmits to sensor RX pin 2) | 17 |
| Display CS / DC | 10 / 4 |
| Display MOSI / MISO / SCK | 11 / 13 / 12 |
| Optional BL control | 5, disabled by default |

GPIO3 is intentionally retained from your working setup, although it is a strapping pin. SCD30 SEL stays grounded; SPS30 SEL stays disconnected. Keep a verified 5 V supply for the SPS30 and common ground. Correct unreliable connector crimps before relying on long-running measurements. Bare SCD30 I2C voltage-level requirements still apply; the firmware does not change the electrical interface.

## Flashing cards

Only the affected card's background pulses, with a steady red outline and a HIGH label. Values remain readable. There is one complete pulse per second, with no added blocking delay. The backlight is not flashed.

Defaults are editable in `Alerts.h`:

| Reading | Trigger (at or above) | Clear (at or below) |
|---|---:|---:|
| CO2 | 1500 ppm | 1300 ppm |
| PM2.5 | 35 ug/m3 | 25 ug/m3 |
| VOC Index | 150 | 120 |
| NOx Index | 20 | 10 |

A reading must stay at/above its trigger for 30 seconds. Dropping below the trigger before then restarts the delay. Once active, the lower clear threshold avoids flickering near the limit. Stale/invalid data clears the alert; an SPS30 warning suppresses its pollution alert while still displaying the warning. Gas alerts require valid indices and five minutes since algorithm initialization/recovery. There is a shared gas card: either high index makes it pulse.

These are adjustable notification defaults, not exposure limits, calibrated safety alarms or a regulatory AQI. The PM2.5 check uses current readings sustained for 30 seconds, not a 24-hour mean. The five-minute gas grace period is an application choice, not a claim of full sensor stabilization. Temperature/humidity do not flash in this version.

## What SGP41 numbers mean

The dashboard now displays official Sensirion **VOC Index and NOx Index**, each on a 1–500 scale. They are relative indicators, not ppm/ppb or an absolute TVOC concentration. VOC baseline is around 100; NOx baseline around 1. Higher values indicate a stronger event relative to the learned background. A low index is not a guarantee of safe air.

- Sensor conditioning runs for 10 seconds.
- Initial algorithm blackout appears as WARMING, not a misleading zero reading.
- When valid indices appear, LEARNING is shown for the first five minutes.
- Learning/adaptation continues beyond this label; leave powered for longer-term consistency. VOC/NOx behavior can take hours to stabilize, especially after new installation.
- State is not saved across reboots. Restarting starts learning again.
- Each algorithm receives fresh raw readings on a nominal one-second schedule. Sampling gaps above 1.5 seconds, failed reads/reinitialization and out-of-range raw inputs reset learning instead of replaying old data.
- Raw VOC/NOx values remain in Serial Monitor for diagnostics.
- Fresh SCD30 temperature/humidity compensates the gas measurement; otherwise 25 C/50% RH defaults are used.

## Optional backlight

At the top of the sketch:

```cpp
constexpr int BACKLIGHT_PIN = -1;
constexpr bool BACKLIGHT_ON = true;
constexpr bool BACKLIGHT_ACTIVE_HIGH = true;
```

Set the pin to 5 only after verifying BL is a compatible logic input or installing an appropriate external LED driver. Never power an unknown LED load from GPIO5. With pin -1, no backlight GPIO is touched. Setting ON=false with control enabled leaves LCD/sensors running, which can test ambient-light readability of a genuinely transflective panel.

## Serial controls

`t`: short screen test; `i`: invert panel colours; `r`: reboot. Long interruptions to sampling restart gas-index learning. No Wi-Fi, touch controls or account required.

## Checks and limitations

Alert-state tests passed for threshold boundaries, 30-second hold, hysteresis, interrupted/stale/NaN readings and timer wraparound. Official algorithm header signatures (`process`, `reset`, default constructors for one-second sampling) were checked. No target firmware compile or physical device test was completed for this version. Read `VALIDATION.md`.

## Threshold rationale and references

- HSE describes consistently >1500 ppm CO2 in occupied rooms as evidence of poor ventilation: https://www.hse.gov.uk/ventilation/using-co2-monitors.htm
- PM2.5 35 ug/m3 is our configurable short-term investigation trigger; it is deliberately not presented as an AQI or exposure standard.
- Sensirion gives example purifier triggers above VOC Index 150 and NOx Index 20. This firmware uses inclusive thresholds and a 30-second hold:
  - https://sensirion.com/media/documents/02232963/6294E043/Info_Note_VOC_Index.pdf
  - https://sensirion.com/media/documents/9F289B95/6294DFFC/Info_Note_NOx_Index.pdf
- Algorithm: https://github.com/Sensirion/arduino-gas-index-algorithm
