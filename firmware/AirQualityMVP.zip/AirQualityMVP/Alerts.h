#pragma once
#include <stdint.h>
#include <math.h>

// Adjustable advisory thresholds, NOT exposure limits or regulatory AQI.
namespace Alerts {
constexpr float CO2_HIGH=1500, CO2_CLEAR=1300; // ppm
constexpr float PM25_HIGH=35, PM25_CLEAR=25;  // ug/m3, current reading
constexpr float VOC_HIGH=150, VOC_CLEAR=120; // Sensirion Index
constexpr float NOX_HIGH=20, NOX_CLEAR=10;   // Sensirion Index
constexpr uint32_t HOLD_MS=30000;
constexpr uint32_t GAS_SETTLE_MS=300000; // Suppress gas alerts for first 5 minutes
constexpr uint32_t FLASH_HALF_MS=500;   // One full pulse per second
struct Latch {
  bool active=false, pending=false;
  uint32_t since=0;
  void update(float value,bool valid,uint32_t now,float high,float clear) {
    if (!valid || !isfinite(value)) { active=false; pending=false; return; }
    if (active) { if (value<=clear) active=false; return; }
    if (value<high) { pending=false; return; }
    if (!pending) { pending=true; since=now; }
    if (uint32_t(now-since)>=HOLD_MS) { active=true; pending=false; }
  }
};
}
