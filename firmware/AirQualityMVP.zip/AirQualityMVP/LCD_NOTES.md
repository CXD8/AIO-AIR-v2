# Manufacturer LCD documents verified

The supplied TK024F3036 bundle confirms:

- Panel specification: TFT/Transflective, 240x320.
- ESP32 sample `main/main.c`: RGB element order and `esp_lcd_panel_invert_color(lcd_panel, false)` after initialization. The custom driver maps false to INVOFF. Although its init sequence temporarily issues INVON, the application overrides that setting afterward. The sketch now defaults to `INVERT_DISPLAY = false`.
- SPI adapter schematic `TK024F304189_SPI.pdf`, sheet 1: BL_CTR is connected to the gate of Q1 (SI2302), switching LED cathodes to ground. R3 is a 100k pull-up to 3.3 V. HIGH = on, LOW = off, floating = on. This applies to the supplied adapter circuit, whose header arrangement matches the photographed board; a different revision needs checking.

To control its backlight, connect display BL to GPIO5 (remove any direct BL-to-3V3 jumper first), then set:

```cpp
constexpr int BACKLIGHT_PIN = 5;
constexpr bool BACKLIGHT_ON = true; // false for ambient-light operation
constexpr bool BACKLIGHT_ACTIVE_HIGH = true;
```

The delivered default stays -1 until that connection is made. The GPIO drives the onboard transistor gate, not the LED current. No external LED driver is needed for this supplied adapter. A pull-up means the backlight can briefly be on during boot/reset before firmware applies OFF.

No other vendor analog/gamma initialization settings were transplanted: the display already works, so the targeted change is inversion only. No byte swapping was introduced. Confirm colours on hardware using serial `t`; `i` remains a temporary inversion toggle.

These findings supersede earlier statements that BL circuitry or transflective construction were unconfirmed. The correction is based on supplied code/schematic, not a physical test.

