#pragma once
#include <math.h>
namespace AirQuality {
// EPA May 2026 table, using latest PM2.5 instead of a 24-hour/NowCast mean.
// Returns -1 for invalid data, 501 to display "500+" (UI cap).
inline int pm25Aqi(float pm) {
  if (!isfinite(pm) || pm<0) return -1;
  if (pm>=325.5f) return 501;
  const int c=int(floorf(pm*10.0f)); // truncate to one decimal before interpolation
  const int lo[]={0,91,355,555,1255,2255};
  const int hi[]={90,354,554,1254,2254,3254};
  const int ilo[]={0,51,101,151,201,301};
  const int ihi[]={50,100,150,200,300,500};
  for (int i=0;i<6;++i) if(c<=hi[i])
    return int(lroundf(float(ihi[i]-ilo[i])*(c-lo[i])/(hi[i]-lo[i])+ilo[i]));
  return 501;
}
// Custom three-colour palette. -1 neutral, 0 green, 1 orange, 2 red.
constexpr float CO2_ORANGE=1000, CO2_RED=1500;
constexpr int VOC_ORANGE=120, VOC_RED=150, NOX_ORANGE=10, NOX_RED=20;
inline int co2Level(float v) { return v>=CO2_RED?2:(v>=CO2_ORANGE?1:0); }
inline int aqiLevel(int a) { return a<0?-1:(a>100?2:(a>50?1:0)); }
inline int gasLevel(int voc,int nox) {
  return voc>=VOC_RED || nox>=NOX_RED ? 2 : (voc>=VOC_ORANGE || nox>=NOX_ORANGE ? 1 : 0);
}
// Application comfort bands, not safety or exposure limits.
inline int tempLevel(float t) { return t<15 || t>30 ? 2 : (t<18 || t>26 ? 1 : 0); }
inline int humidityLevel(float h) { return h<30 || h>70 ? 2 : (h<40 || h>60 ? 1 : 0); }
}
