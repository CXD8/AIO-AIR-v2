// ESP32-S3 / ST7789S 240x320 hardware bring-up. See README.md before powering.
#include <Arduino.h>
#include <Wire.h>
#include <SPI.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ST7789.h>
#include <Adafruit_SCD30.h>
#include <math.h>
#include "Protocol.h"
#include "HomeAssistant.h"
#include "Dashboard.h"
#include "Alerts.h"
#include "Backlight.h"
#include <VOCGasIndexAlgorithm.h>
#include <NOxGasIndexAlgorithm.h>

constexpr int SDA_PIN=8, SCL_PIN=3;
constexpr int TFT_CS=10, TFT_DC=4, TFT_MOSI=11, TFT_MISO=13, TFT_SCK=12;
constexpr int SPS_RX=18, SPS_TX=17;
// Supplied SPI awdapter schematic: BL_CTR drives onboard SI2302 gate.
// Active-high, 100k pull-up to 3V3; connect BL to GPIO5 to enable control.
constexpr int BACKLIGHT_PIN = 5;        // Connect display BL to GPIO5; -1 disables control
constexpr bool BACKLIGHT_ON = true;    // false overrides brightness to OFF
constexpr uint8_t BACKLIGHT_BRIGHTNESS = 20; // 0=off, 255=full; linear PWM duty
constexpr bool BACKLIGHT_ACTIVE_HIGH = true; // false for an active-low driver
static_assert(BACKLIGHT_PIN == -1 || BACKLIGHT_PIN == 5,
              "Use reserved GPIO5 or -1 to avoid sensor/display pin conflicts");
constexpr uint8_t ROTATION=0;       // 0/2 portrait; dashboard requires portrait
constexpr bool INVERT_DISPLAY=false; // Manufacturer ESP32 example uses INVOFF
constexpr uint32_t TFT_HZ=10000000; // Conservative speed for jumper wires

Adafruit_ST7789 tft(&SPI, TFT_CS, TFT_DC, -1); // No exposed reset pin
Adafruit_SCD30 scd;
bool scdUp=false, sgpUp=false, spsUp=false;
bool co2Valid=false, gasValid=false, pmValid=false;
uint32_t co2At=0, gasAt=0, pmAt=0;
uint32_t scdRetry=0, sgpRetry=0, spsRetry=0, sgpStart=0;
uint32_t lastSgp=0, lastScd=0, lastSps=0, lastDraw=0;
uint16_t voc=0, nox=0;
VOCGasIndexAlgorithm vocAlgorithm; // Default 1-second sampling interval
NOxGasIndexAlgorithm noxAlgorithm; // Compatible with default-constructor-only releases
int32_t vocIndex=0, noxIndex=0;
bool indicesValid=false;
uint32_t gasLearningAt=0, gasSampleAt=0;
Alerts::Latch co2Alert, pmAlert, vocAlert, noxAlert;
float pm[10]{};
uint8_t spsState=0;
bool conditioning=false;
const char* scdStatus="not started";
const char* sgpStatus="not started";
const char* spsStatus="not started";

bool fresh(bool valid, uint32_t at, uint32_t age) {
  return valid && uint32_t(millis()-at)<age;
}
bool probe(uint8_t addr) {
  Wire.beginTransmission(addr); return Wire.endTransmission()==0;
}
void scanBus() {
  Serial.println("I2C scan: expected SGP41=0x59, SCD30=0x61");
  // Scan only normal usable addresses. No general-call resets.
  for (uint8_t a=8;a<120;++a) if (probe(a)) Serial.printf("  ACK 0x%02X\n",a);
}
bool sgpCommand(uint16_t cmd, const uint16_t* args, size_t nargs,
                uint16_t* words, size_t nwords, uint32_t waitMs) {
  Wire.beginTransmission(0x59);
  Wire.write(uint8_t(cmd>>8)); Wire.write(uint8_t(cmd));
  for (size_t i=0;i<nargs;++i) {
    uint8_t p[2]={uint8_t(args[i]>>8),uint8_t(args[i])};
    Wire.write(p,2); Wire.write(Protocol::crc8(p,2));
  }
  uint8_t err=Wire.endTransmission();
  if (err) { Serial.printf("SGP41 I2C write error %u\n",err); return false; }
  delay(waitMs);
  if (!nwords) return true;
  size_t needed=nwords*3;
  if (Wire.requestFrom(uint8_t(0x59),needed)!=needed) {
    while (Wire.available()) Wire.read();
    Serial.println("SGP41 short read / timeout"); return false;
  }
  for (size_t i=0;i<nwords;++i) {
    uint8_t p[2]={uint8_t(Wire.read()),uint8_t(Wire.read())};
    uint8_t c=Wire.read();
    if (c!=Protocol::crc8(p,2)) {
      while (Wire.available()) Wire.read();
      Serial.println("SGP41 CRC mismatch"); return false;
    }
    words[i]=uint16_t(p[0])<<8 | p[1];
  }
  return true;
}
void startScd() {
  scdRetry=millis(); co2Valid=false;
  scdUp=probe(0x61) && scd.begin(0x61,&Wire);
  Wire.setClock(100000); Wire.setTimeOut(250);
  scdStatus=scdUp ? "waiting for data" : "init failed";
  Serial.printf("SCD30: %s\n",scdStatus);
  // No forced calibration, altitude, ASC, or persistent settings changed here.
}
void startSgp() {
  sgpRetry=millis(); gasValid=false; sgpUp=false;
  vocAlgorithm.reset(); noxAlgorithm.reset();
  vocIndex=0; noxIndex=0; indicesValid=false; gasSampleAt=0;
  gasLearningAt=millis();
  if (!probe(0x59)) { sgpStatus="missing 0x59"; return; }
  uint16_t test=0;
  if (!sgpCommand(0x3615,nullptr,0,nullptr,0,2) ||
      !sgpCommand(0x280e,nullptr,0,&test,1,330) || (test&3)) {
    sgpStatus="self-test failed"; Serial.printf("SGP41 self-test: 0x%04X\n",test); return;
  }
  sgpUp=true; sgpStart=millis(); lastSgp=sgpStart-1000;
  conditioning=true; sgpStatus="conditioning 10s";
  Serial.println("SGP41 self-test passed; conditioning for 10 seconds");
}
void stuffedWrite(uint8_t b) {
  if (Protocol::escaped(b)) { Serial1.write(uint8_t(0x7d)); Serial1.write(uint8_t(b^0x20)); }
  else Serial1.write(b);
}
bool spsCommand(uint8_t cmd, const uint8_t* data, uint8_t len,
                uint8_t* out, size_t capacity, size_t& received) {
  received=0;
  while (Serial1.available()) Serial1.read();
  Serial1.write(uint8_t(0x7e));
  uint8_t sum=cmd+len;
  stuffedWrite(0); stuffedWrite(cmd); stuffedWrite(len);
  for (uint8_t i=0;i<len;++i) { sum+=data[i]; stuffedWrite(data[i]); }
  stuffedWrite(uint8_t(~sum)); Serial1.write(uint8_t(0x7e));
  Protocol::Frame frame;
  uint32_t start=millis();
  while (uint32_t(millis()-start)<150) {
    while (Serial1.available()) {
      if (!frame.feed(uint8_t(Serial1.read()))) continue;
      if (frame.bytes[0]!=0 || frame.bytes[1]!=cmd) continue;
      spsState=frame.bytes[2];
      if (spsState&0x7f) { Serial.printf("SPS30 command 0x%02X status 0x%02X\n",cmd,spsState); return false; }
      received=frame.bytes[3];
      if (received>capacity) { Serial.println("SPS30 unexpected response length"); return false; }
      if (received) memcpy(out,frame.bytes+4,received);
      return true;
    }
    delay(1);
  }
  Serial.printf("SPS30 timeout/invalid frame for 0x%02X; check 5V, TX/RX, SEL\n",cmd);
  return false;
}
void startSps() {
  spsRetry=millis(); pmValid=false; spsUp=false;
  uint8_t response[64]; size_t n;
  // Wake a sensor left sleeping by earlier firmware, then return it to idle.
  Serial1.write(uint8_t(0xff)); delay(5);
  spsCommand(0x11,nullptr,0,response,sizeof(response),n);
  spsCommand(0x01,nullptr,0,response,sizeof(response),n);
  const uint8_t format[]={0x01,0x03};
  spsUp=spsCommand(0x00,format,2,response,sizeof(response),n);
  spsStatus=spsUp ? "waiting for data" : "no UART response";
  Serial.printf("SPS30: %s\n",spsStatus);
}
void pollScd() {
  if (!scdUp) return;
  if (scd.dataReady()) {
    if (scd.read() && isfinite(scd.CO2) && scd.CO2>0 &&
        isfinite(scd.temperature) && isfinite(scd.relative_humidity)) {
      co2Valid=true; co2At=millis(); scdStatus="OK";
      Serial.printf("SCD30 CO2=%.0f ppm T=%.2f C RH=%.2f %%\n",scd.CO2,scd.temperature,scd.relative_humidity);
    } else { co2Valid=false; scdStatus="read failed"; Serial.println("SCD30 read failed"); }
  }
  uint32_t base=co2Valid ? co2At : scdRetry;
  if (uint32_t(millis()-base)>30000) { scdUp=false; scdStatus="no fresh data"; scdRetry=millis(); }
}
void pollSgp() {
  if (!sgpUp) return;
  // A missed sampling slot invalidates the fixed-interval algorithm history.
  // Restart learning instead of inventing samples or replaying stale values.
  uint32_t sampleNow=millis();
  if (gasSampleAt && uint32_t(sampleNow-gasSampleAt)>1500) {
    vocAlgorithm.reset(); noxAlgorithm.reset(); indicesValid=false;
    gasLearningAt=sampleNow;
    Serial.println("SGP41 sampling gap: restarting index learning");
  }
  gasSampleAt=sampleNow;
  conditioning=uint32_t(sampleNow-sgpStart)<10000;
  uint16_t args[2]={0x8000,0x6666}, result[2]{};
  if (fresh(co2Valid,co2At,10000)) {
    float rh=fmaxf(0,fminf(100,scd.relative_humidity));
    float temp=fmaxf(-45,fminf(130,scd.temperature));
    args[0]=uint16_t(lroundf(rh*65535.0f/100.0f));
    args[1]=uint16_t(lroundf((temp+45)*65535.0f/175.0f));
  }
  if (!sgpCommand(conditioning?0x2612:0x2619,args,2,result,conditioning?1:2,55)) {
    sgpUp=false; gasValid=false; indicesValid=false; sgpStatus="read failed"; sgpRetry=millis();
    sgpCommand(0x3615,nullptr,0,nullptr,0,2); return;
  }
  voc=result[0]; nox=result[1]; gasAt=millis(); gasValid=!conditioning;
  if (!conditioning && (voc==0 || nox==0 || voc>=65000 || nox>=65000)) {
    indicesValid=false; vocAlgorithm.reset(); noxAlgorithm.reset();
    gasLearningAt=millis(); sgpStatus="invalid raw signal";
    Serial.println("SGP41 invalid raw input; index learning reset"); return;
  }
  if (!conditioning) {
    vocIndex=vocAlgorithm.process(voc);
    noxIndex=noxAlgorithm.process(nox);
    indicesValid=vocIndex>=1 && vocIndex<=500 && noxIndex>=1 && noxIndex<=500;
  } else indicesValid=false;
  sgpStatus=conditioning ? "conditioning 10s" : (indicesValid ? "indices ready" : "index warm-up");
  Serial.printf("SGP41 VOC Index=%ld NOx Index=%ld (0=warming up)\n",(long)vocIndex,(long)noxIndex);
  Serial.printf("SGP41 %s VOCraw=%u NOxraw=%u compensation=%s\n",sgpStatus,voc,nox,
    fresh(co2Valid,co2At,10000)?"SCD30":"default 25C/50%RH");
}
void pollSps() {
  if (!spsUp) return;
  uint8_t response[64]; size_t n;
  if (!spsCommand(0x03,nullptr,0,response,sizeof(response),n)) {
    spsUp=false; pmValid=false; spsStatus="UART read failed"; spsRetry=millis(); return;
  }
  if (n==0) {
    if (uint32_t(millis()-(pmValid?pmAt:spsRetry))>30000) {
      spsUp=false; pmValid=false; spsStatus="no fresh data"; spsRetry=millis();
    }
    return;
  }
  if (n!=40) { pmValid=false; spsStatus="bad payload length"; return; }
  for (int i=0;i<10;++i) {
    pm[i]=Protocol::beFloat(response+4*i);
    if (!isfinite(pm[i]) || pm[i]<0) { pmValid=false; spsStatus="invalid PM data"; return; }
  }
  pmValid=true; pmAt=millis(); spsStatus=(spsState&0x80)?"sensor warning":"OK";
  Serial.printf("PM2.5 live US AQI estimate=%d (-1 unavailable, 501 means 500+)\n",
    (spsState&0x80)?-1:AirQuality::pm25Aqi(pm[1]));
  Serial.printf("SPS30 PM1=%.1f PM2.5=%.1f PM4=%.1f PM10=%.1f ug/m3 state=0x%02X\n",
    pm[0],pm[1],pm[2],pm[3],spsState);
}
void line(int y, const String& text, uint16_t color=ST77XX_WHITE, uint8_t size=1) {
  tft.fillRect(0,y,240,8*size+2,ST77XX_BLACK);
  tft.setCursor(6,y); tft.setTextSize(size); tft.setTextColor(color); tft.print(text);
}
void drawDashboard() {
  bool c=fresh(co2Valid,co2At,10000);
  bool g=fresh(gasValid,gasAt,4000) && indicesValid;
  bool p=fresh(pmValid,pmAt,5000);
  uint32_t timeNow=millis();
  bool gasSettled=uint32_t(timeNow-gasLearningAt)>=Alerts::GAS_SETTLE_MS;
  co2Alert.update(scd.CO2,c,timeNow,Alerts::CO2_HIGH,Alerts::CO2_CLEAR);
  pmAlert.update(pm[1],p && !(spsState&0x80),timeNow,Alerts::PM25_HIGH,Alerts::PM25_CLEAR);
  vocAlert.update(vocIndex,g && gasSettled,timeNow,Alerts::VOC_HIGH,Alerts::VOC_CLEAR);
  noxAlert.update(noxIndex,g && gasSettled,timeNow,Alerts::NOX_HIGH,Alerts::NOX_CLEAR);
  Dashboard::draw(tft, c, g, p, scd.CO2, scd.temperature,
    scd.relative_humidity, pm[0], pm[1], pm[3], uint16_t(vocIndex), uint16_t(noxIndex),
    c ? "LIVE" : (co2Valid ? "STALE" : (scdUp ? "WAITING" : "OFFLINE")),
    g ? (gasSettled ? "LIVE" : "LEARNING") : (sgpUp ? "WARMING" : "OFFLINE"),
    p ? ((spsState & 0x80) ? "WARNING" : "LIVE") : (pmValid ? "STALE" : (spsUp ? "WAITING" : "OFFLINE")),
    timeNow/1000, co2Alert.active, pmAlert.active,
    vocAlert.active || noxAlert.active, (timeNow/Alerts::FLASH_HALF_MS)%2==0);
}

void publishSnapshot() {
  HomeLink::Snapshot s{};
  s.readings[HomeLink::CO2]={scd.CO2,co2At,co2Valid};
  s.readings[HomeLink::TEMPERATURE]={scd.temperature,co2At,co2Valid};
  s.readings[HomeLink::HUMIDITY]={scd.relative_humidity,co2At,co2Valid};
  bool goodPm=pmValid && !(spsState&0x80);
  s.readings[HomeLink::PM1]={pm[0],pmAt,goodPm};
  s.readings[HomeLink::PM25]={pm[1],pmAt,goodPm};
  s.readings[HomeLink::PM4]={pm[2],pmAt,goodPm};
  s.readings[HomeLink::PM10]={pm[3],pmAt,goodPm};
  s.readings[HomeLink::VOC_INDEX]={float(vocIndex),gasAt,gasValid && indicesValid};
  s.readings[HomeLink::NOX_INDEX]={float(noxIndex),gasAt,gasValid && indicesValid};
  int aqi=AirQuality::pm25Aqi(pm[1]);
  s.readings[HomeLink::AQI]={float(aqi),pmAt,goodPm && aqi>=0};
  HomeLink::submit(s);
}

void screenTest() {
  Serial.println("Sending screen test (visual verification required; no LCD readback)");
  const uint16_t colors[]={ST77XX_RED,ST77XX_GREEN,ST77XX_BLUE,ST77XX_WHITE,ST77XX_BLACK};
  // Total 400ms: keep short so routine gas sampling is not interrupted for long.
  for (uint16_t c:colors) { tft.fillScreen(c); delay(80); }
  tft.drawRect(0,0,240,320,ST77XX_WHITE);
  tft.fillRect(8,40,70,40,ST77XX_RED); tft.fillRect(85,40,70,40,ST77XX_GREEN);
  tft.fillRect(162,40,70,40,ST77XX_BLUE);
  line(100,"ST7789S 240x320",ST77XX_WHITE,2);
}
void configureBacklight() {
  if (BACKLIGHT_PIN < 0) {
    Serial.println("Backlight unmanaged: BACKLIGHT_PIN=-1"); return;
  }
  uint8_t brightness=BACKLIGHT_ON?BACKLIGHT_BRIGHTNESS:0;
  if(!Backlight::begin(BACKLIGHT_PIN,brightness,BACKLIGHT_ACTIVE_HIGH)) {
    Serial.println("Backlight PWM setup failed; check LEDC resources"); return;
  }
  Serial.printf("Backlight GPIO%d brightness=%u/255\n",BACKLIGHT_PIN,brightness);
}
void setup() {
  Serial.begin(115200); delay(1200); // No indefinite wait for USB serial
  Serial.println("\nAirQualityMVP: ST7789S + SCD30 + SGP41 + SPS30 UART");
  Serial.println("SPS30 needs actual regulated 5V. A 1.1V 5VIN reading is NOT usable.");
  configureBacklight();
  Serial.println("SCD30 bare module I2C needs voltage-level review.");
  Wire.begin(SDA_PIN,SCL_PIN,100000); Wire.setTimeOut(250);
  Serial1.begin(115200,SERIAL_8N1,SPS_RX,SPS_TX);
  SPI.begin(TFT_SCK,TFT_MISO,TFT_MOSI,TFT_CS);
  tft.init(240,320,SPI_MODE0); tft.setSPISpeed(TFT_HZ);
  tft.setRotation(ROTATION); tft.invertDisplay(INVERT_DISPLAY); tft.setTextWrap(false);
  tft.fillScreen(Dashboard::BG); drawDashboard();
  scanBus(); startScd(); startSps(); startSgp();
  HomeLink::begin();
}
void loop() {
  uint32_t now=millis();
  // Sample SGP first. Use elapsed time, not catch-up bursts after a delay.
  if (uint32_t(now-lastSgp)>=1000) {
    if (uint32_t(now-lastSgp)>=1500) lastSgp=now;
    else lastSgp+=1000;
    pollSgp();
  }
  if (uint32_t(now-lastScd)>=1000) { lastScd=now; pollScd(); }
  if (uint32_t(now-lastSps)>=1000) { lastSps=now; pollSps(); }
  if (!scdUp && uint32_t(millis()-scdRetry)>=15000) startScd();
  if (!spsUp && uint32_t(millis()-spsRetry)>=15000) startSps();
  if (!sgpUp && uint32_t(millis()-sgpRetry)>=15000) startSgp();
  if (uint32_t(now-lastDraw)>=250) { lastDraw=now; drawDashboard(); }
  static uint32_t lastNetwork=0;
  if (uint32_t(millis()-lastNetwork)>=1000) { lastNetwork=millis(); publishSnapshot(); }
  if (Serial.available()) {
    char c=Serial.read();
    if (c=='t') { screenTest(); tft.fillScreen(Dashboard::BG); drawDashboard(); }
    if (c=='i') { static bool inverted=INVERT_DISPLAY; inverted=!inverted; tft.invertDisplay(inverted); }
    if (c=='r') ESP.restart();
  }
  delay(2);
}
