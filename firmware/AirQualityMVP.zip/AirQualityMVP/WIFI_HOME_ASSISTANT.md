# Wi-Fi and Home Assistant

1. In Arduino Library Manager install **PubSubClient by Nick O'Leary (2.8 or later)** and **ArduinoJson by Benoit Blanchon (7.x)**. Keep the existing display, SCD30 and Sensirion Gas Index Algorithm libraries installed. Select your working ESP32-S3 board settings.
2. Set up an MQTT broker reachable on your LAN. With Home Assistant OS, install/start the Mosquitto broker app and create device login credentials. Add/configure the **MQTT integration** under Settings → Devices & services, pointing it at that broker. Other Home Assistant installations can use an external Mosquitto broker.
3. Open `NetworkConfig.h` alongside the sketch. Enter your **2.4 GHz** Wi-Fi SSID/password, broker's LAN IP, MQTT username/password, and optional device name. Use the broker IP (often your HA machine's IP), not `http://`, port 8123, or the internal app name `core-mosquitto`. Port 1883 is the default. For a broker that deliberately permits anonymous connections, leave MQTT_USER empty.
4. Upload `AirQualityMVP.ino`. The display footer shows LOCAL (configuration empty/disabled), WIFI? (connecting), MQTT? (Wi-Fi connected, broker pending), ONLINE (MQTT connected), or NET ERR (allocation/task startup failure). Serial at 115200 shows connection status and assigned IP; passwords are not logged.
5. In Home Assistant, look under Settings → Devices & services → MQTT → Devices for **Air Quality Monitor**. Add its entities to your dashboard. No entity YAML is required.

The discovery prefix defaults to `homeassistant`; if your installation changes it, set DISCOVERY_PREFIX and HA_STATUS_TOPIC accordingly. The latter must match HA's configured birth topic, normally `homeassistant/status`, with the default birth payload `online`.

## Entities

| Entity | Unit / interpretation |
| --- | --- |
| Carbon dioxide | ppm (CO2, not carbon monoxide) |
| Temperature | °C |
| Humidity | % relative humidity |
| PM1, PM2.5, PM4, PM10 | µg/m³ |
| VOC index, NOx index | Sensirion dimensionless indices, not gas ppm/ppb |
| Live PM2.5 US AQI estimate | Latest PM2.5 sample mapped to US breakpoints; not official 24-hour AQI or NowCast |
| WiFi signal | dBm, diagnostic |
| Uptime | Seconds since boot, diagnostic; wraps with millis after about 49.7 days |

AQI 501 means above the implemented 500 scale (LCD displays 500+). Gas indices remain unavailable during conditioning/algorithm blackout, then are published while they continue learning; early values are provisional. The existing LCD LEARNING indicator and alert grace period remain in place.

## Behaviour

Measurements update every five seconds. Sensor validity is checked using the original measurement timestamps (CO2/climate <10 seconds, gas <4 seconds, PM/AQI <5 seconds). SPS30 warnings suppress PM and AQI publishing. Invalid/stale measurements become unavailable, never zero. Home Assistant also expires measurements after 30 seconds without updates. Device availability uses MQTT Last Will; unplugging can take approximately a keepalive timeout to show offline.

Discovery messages are retained. Measurements are not retained. Discovery is resent after ESP reconnect or Home Assistant's `online` birth message. Unique IDs use the ESP32 hardware MAC, so changing the friendly name does not create another device. Broker restart and network loss trigger retries automatically. LCD/sensors keep running locally, with all network calls confined to a separate FreeRTOS task and sensor snapshots passed through a copying queue. Actual on-device sampling timing still needs checking with Wi-Fi enabled.

This uses unencrypted MQTT on a trusted LAN; do not expose port 1883 to the internet. Credentials live in NetworkConfig.h and in the flashed firmware—remove them before sharing the project. There is no cloud service, web portal, OTA updater, or remote backlight control in this version.

## Troubleshooting / acceptance check

- WIFI?: check 2.4 GHz coverage, SSID/password and router client restrictions.
- MQTT?: check broker LAN IP, port, user permissions and MQTT integration. Serial MQTT state 4/5 typically means credentials/authorization rejected; -2 commonly indicates the TCP connection failed.
- ONLINE but missing device: ensure HA and the ESP use the same broker and discovery prefix; check broker permissions for `homeassistant/#` and `airquality/#`.
- Disable/re-enable Wi-Fi or stop/restart the broker: local display should keep updating, the gas algorithm should not repeatedly log sampling gaps, and HA should recover automatically.
- Disconnect a sensor: its HA entities should become unavailable while the others continue updating.
- Restart HA: discovery and readings should return. Unplug the ESP: its entities should become unavailable.

Official references: [Home Assistant MQTT](https://www.home-assistant.io/integrations/mqtt/), [MQTT sensor availability and expiry](https://www.home-assistant.io/integrations/sensor.mqtt/), [ArduinoJson 7](https://arduinojson.org/v7/), [PubSubClient](https://github.com/knolleary/pubsubclient).
