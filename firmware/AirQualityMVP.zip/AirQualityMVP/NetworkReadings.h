#pragma once
#include <stdint.h>
#include <math.h>
namespace HomeLink {
enum Reading { CO2, TEMPERATURE, HUMIDITY, PM1, PM25, PM4, PM10,
               VOC_INDEX, NOX_INDEX, AQI, COUNT };
struct Sample { float value; uint32_t at; bool valid; };
struct Snapshot { Sample readings[COUNT]; };
inline uint32_t maxAge(unsigned i) {
  return i<=HUMIDITY ? 10000 : ((i==VOC_INDEX || i==NOX_INDEX) ? 4000 : 5000);
}
inline bool usable(const Sample& s, unsigned i, uint32_t now) {
  return s.valid && isfinite(s.value) && uint32_t(now-s.at)<maxAge(i);
}
}
