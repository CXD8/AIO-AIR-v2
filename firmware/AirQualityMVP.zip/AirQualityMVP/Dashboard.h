#pragma once
#include "AirQuality.h"
#include "HomeAssistant.h"
#include <Adafruit_GFX.h>
#include <Adafruit_ST7789.h>
#include <Fonts/FreeSansBold18pt7b.h>
#include <Fonts/FreeSansBold12pt7b.h>

// UI only: no sensor commands, pin changes, delays or calibration writes.
namespace Dashboard {
constexpr uint16_t BG=0x0862, CARD=0x10C4, BORDER=0x2146;
constexpr uint16_t INK=0xEF7C, MUTED=0x8CD3, TEAL=0x4E78, AMBER=0xFDCF;
// One reusable strip: 42,240 bytes; no PSRAM required.
inline GFXcanvas16& canvas() { static GFXcanvas16 c(240,88); return c; }
inline void small(int x,int y,const String& s,uint16_t col=MUTED) {
  auto& c=canvas(); c.setFont(nullptr); c.setTextSize(1);
  c.setTextColor(col); c.setCursor(x,y); c.print(s);
}
inline void number(int x,int baseline,const String& s,bool large=true,uint16_t col=INK) {
  auto& c=canvas();
  c.setFont(large?&FreeSansBold18pt7b:&FreeSansBold12pt7b);
  c.setTextSize(1); c.setTextColor(col); c.setCursor(x,baseline); c.print(s);
  c.setFont(nullptr);
}
inline uint16_t tint(int level,bool bright=false) {
  if (level==0) return bright?0x1385:0x09E3;
  if (level==1) return bright?0x8B20:0x51E0;
  if (level==2) return bright?0xA165:0x5143;
  return CARD;
}
inline uint16_t edge(int level) {
  return level==0?0x5EAA:(level==1?0xFD20:(level==2?0xFAAA:BORDER));
}
inline void flush(Adafruit_ST7789& tft,int y,int height) {
  tft.drawRGBBitmap(0,y,canvas().getBuffer(),240,height);
}
inline String value(float v,int decimals,float maxValue) {
  if (!isfinite(v) || v<0) return "--";
  if (v>maxValue) return ">"+String(maxValue,0);
  return String(v,decimals);
}
// Shared card primitives: 8px outer margin, 12px content inset, 8px corners.
inline void card(int x,int width,int height,int level,bool flash=false) {
  auto& c=canvas();
  c.fillRoundRect(x,0,width,height,8,tint(level,flash));
  c.drawRoundRect(x,0,width,height,8,edge(level));
}
inline void beginStrip() { canvas().fillScreen(BG); canvas().setTextWrap(false); }
// Two-second breathing dot, drawn during the existing 250ms refresh.
// Indicates fresh data, independently of the card's air-quality colour.
inline void statusDot(int x,int y,bool live) {
  auto& c=canvas();
  if(!live) { c.drawCircle(x,y,3,MUTED); return; }
  uint32_t t=millis()%2000;
  uint32_t ramp=t<1000?t:2000-t;
  uint8_t light=uint8_t(64+191*ramp/1000);
  uint16_t colour=uint16_t((uint16_t(60*light/255)>>3)<<11)
    | uint16_t((uint16_t(220*light/255)>>2)<<5)
    | uint16_t(uint16_t(145*light/255)>>3);
  c.drawCircle(x,y,5,0x1947);
  c.fillCircle(x,y,3,colour);
}
inline void header(const char* label,const char* state,int level) {
  small(20,10,label,INK);
  if(strcmp(state,"LIVE")==0) { statusDot(215,14,true); return; }
  // Non-live states retain explicit text so warnings are unambiguous.
  auto& c=canvas(); int w=strlen(state)*6+12;
  c.fillRoundRect(220-w,6,w,16,5,CARD);
  small(226-w,10,state,level<0?MUTED:edge(level));
}
inline void fittedNumber(int x,int baseline,int width,const String& text) {
  auto& c=canvas(); int16_t bx,by; uint16_t w,h;
  c.setFont(&FreeSansBold18pt7b); c.setTextSize(1);
  c.getTextBounds(text,0,baseline,&bx,&by,&w,&h);
  bool large=w<=width;
  c.setFont(large?&FreeSansBold18pt7b:&FreeSansBold12pt7b);
  c.getTextBounds(text,0,baseline,&bx,&by,&w,&h);
  if(w<=width) number(x-bx,baseline,text,large);
  else { c.setFont(nullptr); c.setTextSize(2); c.setTextColor(INK);
    c.setCursor(x,baseline-14); c.print("--"); c.setTextSize(1); }
}
inline void compactValue(int x,int y,const String& text,const char* unit) {
  auto& c=canvas(); c.setFont(nullptr); c.setTextSize(2); c.setTextColor(INK);
  c.setCursor(x,y); c.print(text); c.setTextSize(1);
  if(unit[0]) small(x+84,y+7,unit);
}
inline void draw(Adafruit_ST7789& tft,bool co2OK,bool gasOK,bool pmOK,
                 float co2,float temp,float rh,float pm1,float pm25,float pm10,
                 uint16_t voc,uint16_t nox,const char* co2State,const char* gasState,
                 const char* pmState,uint32_t seconds,bool co2High,bool pmHigh,bool gasHigh,bool phase) {
  auto& c=canvas();
  if (!c.getBuffer()) {
    tft.setFont(nullptr); tft.setTextSize(1); tft.setTextColor(INK,BG);
    tft.setCursor(8,8); tft.print("UI memory unavailable"); return;
  }
  bool pmTrusted=pmOK && strcmp(pmState,"WARNING")!=0;
  int aqi=pmTrusted?AirQuality::pm25Aqi(pm25):-1;
  int co2Level=co2OK?AirQuality::co2Level(co2):-1;
  int pmLevel=AirQuality::aqiLevel(aqi);
  bool learning=strcmp(gasState,"LEARNING")==0;
  int gasLevel=gasOK && !learning?AirQuality::gasLevel(voc,nox):-1;

  beginStrip();
  small(8,3,"AIR QUALITY",INK);
  small(8,18,"PM2.5 / US AQI EST");
  String aq=aqi<0?"--":(aqi>500?"500+":String(aqi));
  int badgeWidth=aq.length()*12+16;
  c.fillRoundRect(232-badgeWidth,0,badgeWidth,30,8,tint(pmLevel));
  c.drawRoundRect(232-badgeWidth,0,badgeWidth,30,8,edge(pmLevel));
  compactValue(240-badgeWidth,8,aq,"");
  // Subtitle is kept left of the AQI badge even for the 500+ case.
  flush(tft,0,32);

  beginStrip(); card(8,224,70,co2High?2:co2Level,co2High && phase);
  header("CO2",co2High?"HIGH":co2State,co2High?2:co2Level);
  fittedNumber(20,58,154,co2OK?value(co2,0,99999):"--");
  small(196,50,"ppm");
  flush(tft,36,70);

  beginStrip(); card(8,224,78,pmHigh?2:pmLevel,pmHigh && phase);
  header("PM2.5",pmHigh?"HIGH":pmState,pmHigh?2:pmLevel);
  fittedNumber(20,55,154,pmOK?value(pm25,1,9999):"--");
  small(190,47,"ug/m3");
  c.drawFastHLine(20,61,200,BORDER);
  small(20,67,pmTrusted?String("PM1 ")+value(pm1,1,9999):"PM1 --");
  small(122,67,pmTrusted?String("PM10 ")+value(pm10,1,9999):"PM10 --");
  flush(tft,110,78);

  beginStrip();
  int tl=co2OK?AirQuality::tempLevel(temp):-1;
  int hl=co2OK?AirQuality::humidityLevel(rh):-1;
  card(8,108,50,tl); card(124,108,50,hl);
  small(20,10,"TEMP",INK); small(136,10,"HUMIDITY",INK);
  statusDot(105,13,co2OK); statusDot(221,13,co2OK);
  compactValue(20,28,co2OK && isfinite(temp)?String(temp,1):"--","");
  compactValue(136,28,co2OK?String(rh,0):"--","");
  small(102,35,"C"); small(218,35,"%");
  flush(tft,192,50);

  beginStrip(); card(8,224,54,gasHigh?2:gasLevel,gasHigh && phase);
  header("GAS INDEX",gasHigh?"HIGH":gasState,gasHigh?2:gasLevel);
  c.drawFastVLine(120,29,16,BORDER);
  small(20,36,"VOC"); small(132,36,"NOx");
  compactValue(48,29,gasOK?String(voc):"--","");
  compactValue(160,29,gasOK?String(nox):"--","");
  flush(tft,246,54);

  beginStrip();
  char uptime[16];
  if(seconds>=86400) snprintf(uptime,sizeof(uptime),"%lud %02luh",
    (unsigned long)(seconds/86400),(unsigned long)((seconds/3600)%24));
  else snprintf(uptime,sizeof(uptime),"%02lu:%02lu:%02lu",
    (unsigned long)(seconds/3600),(unsigned long)((seconds/60)%60),(unsigned long)(seconds%60));
  small(8,5,uptime); small(82,5,HomeLink::status());
  int live=int(co2OK)+int(gasOK)+int(pmTrusted);
  small(178,5,String(live)+"/3",live==3?TEAL:MUTED);
  statusDot(221,8,live==3);
  flush(tft,304,16);
}
}
