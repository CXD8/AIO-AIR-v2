#pragma once
#include <WiFi.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <atomic>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/queue.h>
#include "NetworkConfig.h"
#include "NetworkReadings.h"

namespace HomeLink {
// Only this task touches network clients. Sensor data crosses a copying queue.
static QueueHandle_t queue=nullptr;
static std::atomic<int> connection{0}; // 0 disabled, 1 WiFi wait, 2 MQTT wait, 3 online, 4 error
inline const char* status() {
  switch(connection.load()) {
    case 1:return "WIFI?"; case 2:return "MQTT?"; case 3:return "ONLINE";
    case 4:return "NET ERR"; default:return "LOCAL";
  }
}
static WiFiClient transport;
static PubSubClient mqtt(transport);
static String id, base;
static bool discoveryNeeded=true;
struct Entity { const char* key; const char* name; const char* unit; const char* deviceClass; uint8_t decimals; };
static const Entity entities[]={
  {"co2","Carbon dioxide","ppm","carbon_dioxide",0},
  {"temperature","Temperature","°C","temperature",1},
  {"humidity","Humidity","%","humidity",1},
  {"pm1","PM1","µg/m³","pm1",1},
  {"pm25","PM2.5","µg/m³","pm25",1},
  {"pm4","PM4","µg/m³",nullptr,1},
  {"pm10","PM10","µg/m³","pm10",1},
  {"voc_index","VOC index",nullptr,nullptr,0},
  {"nox_index","NOx index",nullptr,nullptr,0},
  {"aqi","Live PM2.5 US AQI estimate",nullptr,"aqi",0},
  {"rssi","WiFi signal","dBm","signal_strength",0},
  {"uptime","Uptime","s","duration",0}
};
static_assert(sizeof(entities)/sizeof(entities[0])==COUNT+2,"Entity order must match snapshot");
inline void message(char* topic, uint8_t* payload, unsigned int length) {
  if (!strcmp(topic,NetworkConfig::HA_STATUS_TOPIC) && length==6 && !memcmp(payload,"online",6))
    discoveryNeeded=true;
}
inline bool discover() {
  for (unsigned i=0;i<COUNT+2;++i) {
    const Entity& e=entities[i];
    String root=base+"/"+e.key;
    JsonDocument doc;
    doc["name"]=e.name;
    doc["unique_id"]=id+"_"+e.key;
    doc["state_topic"]=root+"/state";
    doc["state_class"]="measurement";
    doc["expire_after"]=30;
    doc["suggested_display_precision"]=e.decimals;
    if(e.unit) doc["unit_of_measurement"]=e.unit;
    if(e.deviceClass) doc["device_class"]=e.deviceClass;
    if(i>=COUNT) doc["entity_category"]="diagnostic";
    doc["availability_mode"]="all";
    JsonArray av=doc["availability"].to<JsonArray>();
    av.add<JsonObject>()["topic"]=base+"/availability";
    av.add<JsonObject>()["topic"]=root+"/availability";
    JsonObject device=doc["device"].to<JsonObject>();
    device["identifiers"].to<JsonArray>().add(id);
    device["name"]=NetworkConfig::DEVICE_NAME;
    device["model"]="ESP32-S3 / SCD30 / SGP41 / SPS30";
    device["sw_version"]="AirQualityMVP WiFi 1";
    char payload[1536];
    if(doc.overflowed() || measureJson(doc)>=sizeof(payload)) return false;
    serializeJson(doc,payload,sizeof(payload));
    String topic=String(NetworkConfig::DISCOVERY_PREFIX)+"/sensor/"+id+"/"+e.key+"/config";
    if(!mqtt.publish(topic.c_str(),payload,true)) return false;
  }
  return true;
}
inline void publishReadings(const Snapshot& latest) {
  uint32_t now=millis();
  for(unsigned i=0;i<COUNT+2;++i) {
    bool valid=i>=COUNT || usable(latest.readings[i],i,now);
    float value=i<COUNT ? latest.readings[i].value : (i==COUNT ? float(WiFi.RSSI()) : float(now/1000));
    String root=base+"/"+entities[i].key;
    if(valid) {
      char text[40]; snprintf(text,sizeof(text),"%.*f",entities[i].decimals,double(value));
      // Never retain measurements: old readings must not resurrect on restart.
      valid=mqtt.publish((root+"/state").c_str(),text,false);
    }
    mqtt.publish((root+"/availability").c_str(),valid?"online":"offline",false);
  }
}
inline void worker(void*) {
  char suffix[20]; snprintf(suffix,sizeof(suffix),"%012llx",(unsigned long long)ESP.getEfuseMac());
  id=String("airquality_")+suffix; base=String("airquality/")+suffix;
  mqtt.setServer(NetworkConfig::MQTT_HOST,NetworkConfig::MQTT_PORT);
  mqtt.setCallback(message); mqtt.setKeepAlive(15); mqtt.setSocketTimeout(2);
  if(!mqtt.setBufferSize(2048)) { connection.store(4); vTaskDelete(nullptr); return; }
  WiFi.mode(WIFI_STA); WiFi.setAutoReconnect(true);
  WiFi.begin(NetworkConfig::WIFI_SSID,NetworkConfig::WIFI_PASSWORD);
  uint32_t wifiAttempt=millis(), mqttAttempt=millis()-10000, lastPublish=millis()-5000;
  uint32_t lastDiscovery=millis()-10000;
  bool wasOnline=false;
  Snapshot latest{};
  for(;;) {
    xQueueReceive(queue,&latest,0);
    uint32_t now=millis();
    if(WiFi.status()!=WL_CONNECTED) {
      connection.store(1);
      if(wasOnline) { transport.stop(); wasOnline=false; }
      if(uint32_t(now-wifiAttempt)>=20000) { wifiAttempt=now; WiFi.reconnect(); }
    } else {
      if(!mqtt.connected()) {
        connection.store(2); wasOnline=false;
        if(uint32_t(now-mqttAttempt)>=10000) {
          mqttAttempt=now;
          String availability=base+"/availability";
          const char* user=NetworkConfig::MQTT_USER[0]?NetworkConfig::MQTT_USER:nullptr;
          if(mqtt.connect(id.c_str(),user,user?NetworkConfig::MQTT_PASSWORD:nullptr,
                          availability.c_str(),1,true,"offline")) {
            mqtt.subscribe(NetworkConfig::HA_STATUS_TOPIC);
            mqtt.publish(availability.c_str(),"online",true);
            discoveryNeeded=true; lastDiscovery=millis()-10000; lastPublish=millis()-5000;
            Serial.printf("Home Assistant MQTT connected: %s, IP %s\n",id.c_str(),WiFi.localIP().toString().c_str());
          } else Serial.printf("MQTT connect failed (%d); retry in 10s\n",mqtt.state());
        }
      }
      if(mqtt.connected()) {
        wasOnline=true; connection.store(3); mqtt.loop();
        if(discoveryNeeded && uint32_t(millis()-lastDiscovery)>=10000) {
          lastDiscovery=millis(); discoveryNeeded=!discover();
          lastPublish=millis()-5000;
        }
        if(uint32_t(millis()-lastPublish)>=5000) {
          lastPublish=millis(); xQueueReceive(queue,&latest,0); publishReadings(latest);
        }
      }
    }
    vTaskDelay(pdMS_TO_TICKS(100));
  }
}
inline void begin() {
  if(!NetworkConfig::ENABLED || !NetworkConfig::WIFI_SSID[0] || !NetworkConfig::MQTT_HOST[0]) {
    Serial.println("Network disabled: fill NetworkConfig.h to enable WiFi/MQTT"); return;
  }
  queue=xQueueCreate(1,sizeof(Snapshot));
  if(!queue) { connection.store(4); return; }
  connection.store(1);
  if(xTaskCreate(worker,"air-mqtt",8192,nullptr,1,nullptr)!=pdPASS) {
    vQueueDelete(queue); queue=nullptr; connection.store(4);
  }
}
inline void submit(const Snapshot& snapshot) { if(queue) xQueueOverwrite(queue,&snapshot); }
}
