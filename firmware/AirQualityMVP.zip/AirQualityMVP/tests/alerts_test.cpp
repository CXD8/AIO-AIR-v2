#include "../Alerts.h"
#include <assert.h>
#include <stdio.h>
int main() {
 Alerts::Latch a;
 a.update(1500,true,100,1500,1300); assert(!a.active);
 a.update(1500,true,30099,1500,1300); assert(!a.active);
 a.update(1500,true,30100,1500,1300); assert(a.active);
 a.update(1400,true,31000,1500,1300); assert(a.active);
 a.update(1300,true,32000,1500,1300); assert(!a.active);
 a.update(2000,true,33000,1500,1300);
 a.update(1400,true,34000,1500,1300); assert(!a.pending);
 a.update(2000,true,35000,1500,1300);
 a.update(2000,false,65000,1500,1300); assert(!a.active && !a.pending);
 a.update(NAN,true,66000,1500,1300); assert(!a.active);
 uint32_t start=0xfffff000;
 a.update(2000,true,start,1500,1300);
 a.update(2000,true,uint32_t(start+30000),1500,1300); assert(a.active);
 a.update(2000,false,uint32_t(start+31000),1500,1300); assert(!a.active);
 puts("PASS: threshold, sustained hold, hysteresis, invalid/stale suppression, wraparound");
}
