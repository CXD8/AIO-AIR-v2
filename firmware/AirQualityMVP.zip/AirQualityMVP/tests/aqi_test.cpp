#include "../AirQuality.h"
#include <assert.h>
#include <stdio.h>
int main() {
 using namespace AirQuality;
 assert(pm25Aqi(0)==0); assert(pm25Aqi(9)==50); assert(pm25Aqi(9.1f)==51);
 assert(pm25Aqi(35.4f)==100); assert(pm25Aqi(35.5f)==101);
 assert(pm25Aqi(55.4f)==150); assert(pm25Aqi(55.5f)==151);
 assert(pm25Aqi(125.4f)==200); assert(pm25Aqi(125.5f)==201);
 assert(pm25Aqi(225.4f)==300); assert(pm25Aqi(225.5f)==301);
 assert(pm25Aqi(325.4f)==500); assert(pm25Aqi(325.5f)==501);
 assert(pm25Aqi(35.49f)==100); assert(pm25Aqi(35.9f)==102);
 assert(pm25Aqi(-1)==-1); assert(pm25Aqi(NAN)==-1); assert(pm25Aqi(INFINITY)==-1);
 int prev=-1; for(int i=0;i<10000;++i){int a=pm25Aqi(i/10.0f);assert(a>=prev);prev=a;}
 assert(aqiLevel(50)==0 && aqiLevel(51)==1 && aqiLevel(101)==2);
 assert(co2Level(999)==0 && co2Level(1000)==1 && co2Level(1500)==2);
 assert(gasLevel(100,1)==0 && gasLevel(120,1)==1 && gasLevel(100,20)==2);
 assert(tempLevel(22)==0 && tempLevel(17)==1 && tempLevel(31)==2);
 assert(humidityLevel(50)==0 && humidityLevel(35)==1 && humidityLevel(75)==2);
 puts("PASS: AQI breakpoints, truncation, invalid input, overflow cap, monotonicity, colours");
}
