#include "../Protocol.h"
#include <assert.h>
#include <vector>
#include <stdio.h>
using namespace Protocol;
std::vector<uint8_t> encode(std::vector<uint8_t> body) {
  uint8_t sum=0; for (auto b:body) sum+=b;
  body.push_back(uint8_t(~sum));
  std::vector<uint8_t> wire{0x7e};
  for (auto b:body) {
    if (escaped(b)) { wire.push_back(0x7d); wire.push_back(b^0x20); }
    else wire.push_back(b);
  }
  wire.push_back(0x7e); return wire;
}
int main() {
  uint8_t word[]={0xbe,0xef}; assert(crc8(word,2)==0x92);
  uint8_t rh[]={0x80,0}; assert(crc8(rh,2)==0xa2);
  uint8_t temp[]={0x66,0x66}; assert(crc8(temp,2)==0x93);
  uint8_t f[]={0x41,0x48,0,0}; assert(beFloat(f)==12.5f);
  Frame p;
  // Published SPS30 start-measurement response.
  uint8_t ack[]={0x7e,0,0,0,0,0xff,0x7e};
  int valid=0; for (auto b:ack) valid+=p.feed(b); assert(valid==1);
  auto escapedPayload=encode({0,3,0x80,4,0x7e,0x7d,0x11,0x13});
  valid=0; for (auto b:escapedPayload) valid+=p.feed(b);
  assert(valid==1 && p.bytes[2]==0x80 && p.bytes[3]==4 && p.bytes[4]==0x7e && p.bytes[7]==0x13);
  auto bad=encode({0,3,0,0}); bad[2]^=1;
  valid=0; for (auto b:bad) valid+=p.feed(b); assert(valid==0);
  // Incorrect declared length, truncated escape, and oversize frames rejected.
  auto badLength=encode({0,3,0,5,1});
  for (auto b:badLength) assert(!p.feed(b));
  uint8_t truncated[]={0x7e,0,0,0,0,0xff,0x7d,0x7e};
  for (auto b:truncated) assert(!p.feed(b));
  p.feed(0x7e); for(int i=0;i<300;++i) assert(!p.feed(0));
  assert(!p.feed(0x7e));
  valid=0; for (auto b:ack) valid+=p.feed(b); assert(valid==1);
  puts("PASS: CRC vectors, IEEE754 decode, SHDLC escaping/checksum/length/overflow/recovery");
}
