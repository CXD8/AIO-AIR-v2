#include "../NetworkReadings.h"
#include <assert.h>
#include <limits>
int main() {
  using namespace HomeLink;
  Sample s{600,1000,true};
  assert(usable(s,CO2,10999));
  assert(!usable(s,CO2,11000));
  assert(usable(s,VOC_INDEX,4999));
  assert(!usable(s,VOC_INDEX,5000));
  assert(usable(s,PM25,5999));
  assert(!usable(s,AQI,6000));
  s.valid=false; assert(!usable(s,CO2,1001));
  s.valid=true; s.value=std::numeric_limits<float>::quiet_NaN();
  assert(!usable(s,CO2,1001));
  s.value=std::numeric_limits<float>::infinity(); assert(!usable(s,PM25,1001));
  s.value=0; s.at=0xffffff00U;
  assert(usable(s,PM25,100)); // Genuine zero and wraparound are valid.
  assert(!usable(s,PM25,6000));
}
