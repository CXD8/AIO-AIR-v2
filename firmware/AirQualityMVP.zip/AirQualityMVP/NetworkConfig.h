#pragma once
#include <stdint.h>
// Fill these in locally. Do not share this file after adding passwords.
namespace NetworkConfig {
constexpr bool ENABLED = true; // Empty SSID/host also disables networking.
constexpr char WIFI_SSID[] = ""; // 2.4 GHz network
constexpr char WIFI_PASSWORD[] = "";
constexpr char MQTT_HOST[] = ""; // Broker LAN IP, e.g. 192.168.1.50; no http://
constexpr uint16_t MQTT_PORT = 1883;
constexpr char MQTT_USER[] = "";
constexpr char MQTT_PASSWORD[] = "";
constexpr char DEVICE_NAME[] = "Air Quality Monitor";
constexpr char DISCOVERY_PREFIX[] = "homeassistant";
constexpr char HA_STATUS_TOPIC[] = "homeassistant/status";
// Plain MQTT for a trusted LAN. This firmware does not implement TLS.
}
